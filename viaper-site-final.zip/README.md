# VIAPER Site

Site institucional da VIAPER pronto para GitHub Pages.

## Estrutura
- `index.html`
- `styles.css`
- `script.js`
- `assets/viaper-logo-site.png`

## Publicar no GitHub Pages
1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta.
3. Vá em **Settings > Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve.

Seu site ficará em:
`https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/`
